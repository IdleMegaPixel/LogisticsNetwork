This project exist beacause I had enough doing roundtrips beetween refinery and production, checking the wiki or using excel to calculate.<br/>
Feel free to use the code or fork the project if you need (source [here](https://github.com/NicolasBarlogis/foxhole-logi-calculator "here"))<br/>
Data where updated on the 19th of May 2021.<br/>

## Roadmap
Todo
- ~~Add time estimation to MPF~~
- ~~Add all missing data~~ Thanks a lot to **[FRg] Molotof** for supplying all data
- Add Colonials data
- ~~Add ammunitions used by every weapon/vehicle~~
- ~~Add spreadsheet to factory~~
- Refactor code (lot of duplications, coded quickly and badlly)

<br/>

Might do

- Portable app
- Create similar tool for other purposes (bunker upgrade cost, structure destruction cost, ...)


## Recruitment
You spend time understanding the game and are interested in all its aspect ? Then join a great french (mostly Warden) regiment: **MIAOW** !

Mp Biobazard, The Sage or me (Krun) in game !